﻿// Задача 1: Напишите программу, которая на вход
// принимает позиции элемента в двумерном массиве, и
// возвращает значение этого элемента или же указание,
// что такого элемента нет

// int[,] FillMatrix(int rows, int cols)
// {
//     int[,] matrix = new int[rows, cols];
//     Random rnd = new Random();
//     // Матрица, размер: rows стр и cols столбцов
//     for (int i = 0; i < rows; i++) // i < matrix.GetLength(0), стр
//     {
//         // j, m, k
//         for (int j = 0; j < cols; j++)// j < matrix.GetLength(1), столб
//         {
//             matrix[i, j] = rnd.Next(11); // [0; 10], 11 не попадет
//         }
//     }
//     return matrix;
// }

// Console.Write("Введите количество строк: ");
// int row = Convert.ToInt32(Console.ReadLine());
// Console.Write("Введите количество столбцов: ");
// int cols = Convert.ToInt32(Console.ReadLine());
// int[,] res = FillMatrix(row, cols);

// void PrintMatrix(int[,] matr)
// {
//     for (int i = 0; i < matr.GetLength(0); i++) //  стр 
//     {
//         for (int j = 0; j < matr.GetLength(1); j++)// столб
//         {
//             Console.Write($"{matr[i, j]}\t"); // \t = 4 пробела
//         }
//         Console.WriteLine();
//     }
// }

// PrintMatrix(res);

// Console.Write("Введите номер строки элемента: ");
// int Numberrows = Convert.ToInt32(Console.ReadLine());
// Console.Write("Введите номер столбца элемента: ");
// int Numbercols = Convert.ToInt32(Console.ReadLine());
// if ((Numberrows <= row-1 && Numberrows >=0) && (Numbercols <= cols-1 && Numbercols >=0))
// {
//     Console.Write($"Значение элемента массива = {res[Numberrows, Numbercols]} ");
// }
// else 
// {
//     Console.Write("Такого элемента в массиве нет ");
// }

// Задача 2: Задайте двумерный массив. Напишите
// программу, которая поменяет местами первую и
// последнюю строку массива.

// int[,] FillMatrix(int rows, int cols)
// {
//     int[,] matrix = new int[rows, cols];
//     Random rnd = new Random();
//     // Матрица, размер: rows стр и cols столбцов
//     for (int i = 0; i < rows; i++) // i < matrix.GetLength(0), стр
//     {
//         // j, m, k
//         for (int j = 0; j < cols; j++)// j < matrix.GetLength(1), столб
//         {
//             matrix[i, j] = rnd.Next(11); // [0; 10], 11 не попадет
//         }
//     }
//     return matrix;
// }
// Console.Write("Введите количество строк: ");
// int row = Convert.ToInt32(Console.ReadLine());
// Console.Write("Введите количество столбцов: ");
// int cols = Convert.ToInt32(Console.ReadLine());
// int[,] res = FillMatrix(row, cols);

// void PrintMatrix(int[,] matr)
// {
//     for (int i = 0; i < matr.GetLength(0); i++) //  стр 
//     {
//         for (int j = 0; j < matr.GetLength(1); j++)// столб
//         {
//             Console.Write($"{matr[i, j]}\t"); // \t = 4 пробела
//         }
//         Console.WriteLine();
//     }
// }
// PrintMatrix(res);
//  Console.WriteLine();

// for (int i = 0; i <= cols-1;i++ )
// {
//     int temp = res[0,i];
//     res [0,i] = res[row-1,i];
//     res[row-1,i] = temp;
// }
// PrintMatrix(res);

// Задача 3: Задайте прямоугольный двумерный массив.
// Напишите программу, которая будет находить строку с
// наименьшей суммой элементов.
int[,] FillMatrix(int rows, int cols)
{
    int[,] matrix = new int[rows, cols];
    Random rnd = new Random();
    // Матрица, размер: rows стр и cols столбцов
    for (int i = 0; i < rows; i++) // i < matrix.GetLength(0), стр
    {
        // j, m, k
        for (int j = 0; j < cols; j++)// j < matrix.GetLength(1), столб
        {
            matrix[i, j] = rnd.Next(11); // [0; 10], 11 не попадет
        }
    }
    return matrix;
}
Console.Write("Введите количество строк: ");
int row = Convert.ToInt32(Console.ReadLine());
Console.Write("Введите количество столбцов: ");
int cols = Convert.ToInt32(Console.ReadLine());
int[,] res = FillMatrix(row, cols);

void PrintMatrix(int[,] matr)
{
    for (int i = 0; i < matr.GetLength(0); i++) //  стр 
    {
        for (int j = 0; j < matr.GetLength(1); j++)// столб
        {
            Console.Write($"{matr[i, j]}\t"); // \t = 4 пробела
        }
        Console.WriteLine();
    }
}
PrintMatrix(res);
 Console.WriteLine();

 int m = 0;
 int SumMax = 0;
    for (int i = 0; i < res.GetLength(0); i++) //  стр 
    {int sum = 0;
        for (int j = 0; j < res.GetLength(1); j++)// столб
        {
            sum = sum + res[i,j]; // \t = 4 пробела
            
        }
        if (SumMax > sum)
        {
            SumMax = sum;
            m = i;
        }

    SumMax = sum;
    }
    Console.Write($"Строка с индексом {m} ");


